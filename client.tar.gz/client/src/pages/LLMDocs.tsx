import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { BookOpen, Box, Copy, Download, FileText, RefreshCw, Sparkles, Wand2 } from "lucide-react";
import { useState } from "react";
import { Streamdown } from "streamdown";
import { toast } from "sonner";

export default function LLMDocs() {
  const { data: packages } = trpc.packages.list.useQuery();
  const [selectedPackage, setSelectedPackage] = useState("");
  const [docType, setDocType] = useState<"integration" | "technical" | "guide">("integration");
  const [generatedDoc, setGeneratedDoc] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const generateMut = trpc.dashboard.generateDocs.useMutation({
    onSuccess: (data) => {
      const text = typeof data.content === "string" ? data.content : JSON.stringify(data.content);
      setGeneratedDoc(text);
      setIsGenerating(false);
      toast.success("Documentação gerada com sucesso!");
    },
    onError: (err) => {
      setIsGenerating(false);
      toast.error("Erro ao gerar documentação", { description: err.message });
    },
  });

  const handleGenerate = () => {
    if (!selectedPackage) return;
    setIsGenerating(true);
    setGeneratedDoc(null);
    generateMut.mutate({ packageId: Number(selectedPackage), docType });
  };

  const copyDoc = () => {
    if (generatedDoc) {
      navigator.clipboard.writeText(generatedDoc);
      toast.success("Documentação copiada!");
    }
  };

  const downloadDoc = () => {
    if (!generatedDoc) return;
    const blob = new Blob([generatedDoc], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `docs-${selectedPackage}-${docType}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const docTypeLabels = {
    integration: "Guia de Integração",
    technical: "Documentação Técnica",
    guide: "Manual do Usuário",
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Documentação LLM</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Gere documentação técnica automaticamente com IA baseada nos seus packages
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Config Panel */}
        <Card className="border-border/50 bg-card/50 lg:col-span-1">
          <CardHeader className="pb-4">
            <CardTitle className="text-base flex items-center gap-2">
              <Wand2 className="h-5 w-5 text-primary" /> Configurar Geração
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Package</label>
              <Select value={selectedPackage} onValueChange={setSelectedPackage}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um package" />
                </SelectTrigger>
                <SelectContent>
                  {packages?.map((p) => (
                    <SelectItem key={p.id} value={String(p.id)}>
                      <div className="flex items-center gap-2">
                        <Box className="h-3.5 w-3.5 text-muted-foreground" />
                        {p.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm font-medium">Tipo de Documentação</label>
              <Select value={docType} onValueChange={(v) => setDocType(v as typeof docType)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="integration">
                    <div className="flex items-center gap-2">
                      <FileText className="h-3.5 w-3.5" /> Guia de Integração
                    </div>
                  </SelectItem>
                  <SelectItem value="technical">
                    <div className="flex items-center gap-2">
                      <BookOpen className="h-3.5 w-3.5" /> Documentação Técnica
                    </div>
                  </SelectItem>
                  <SelectItem value="guide">
                    <div className="flex items-center gap-2">
                      <Sparkles className="h-3.5 w-3.5" /> Manual do Usuário
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="rounded-xl bg-primary/5 border border-primary/20 p-4 space-y-2">
              <p className="text-xs font-semibold text-primary">O que a IA vai gerar:</p>
              {docType === "integration" && (
                <ul className="text-xs text-muted-foreground space-y-1">
                  <li>• Passos de integração passo a passo</li>
                  <li>• Exemplos de código</li>
                  <li>• Configuração de autenticação</li>
                  <li>• Troubleshooting comum</li>
                </ul>
              )}
              {docType === "technical" && (
                <ul className="text-xs text-muted-foreground space-y-1">
                  <li>• Especificações técnicas</li>
                  <li>• Endpoints e parâmetros</li>
                  <li>• Estrutura de dados</li>
                  <li>• Fluxos de autenticação</li>
                </ul>
              )}
              {docType === "guide" && (
                <ul className="text-xs text-muted-foreground space-y-1">
                  <li>• Guia para usuário final</li>
                  <li>• Como ativar a key</li>
                  <li>• Registrar dispositivo</li>
                  <li>• FAQ e suporte</li>
                </ul>
              )}
            </div>

            <Button
              className="w-full gap-2 glow-primary"
              onClick={handleGenerate}
              disabled={!selectedPackage || isGenerating}
              size="lg"
            >
              {isGenerating ? (
                <><RefreshCw className="h-4 w-4 animate-spin" /> Gerando com IA...</>
              ) : (
                <><Sparkles className="h-4 w-4" /> Gerar Documentação</>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Output Panel */}
        <Card className="border-border/50 bg-card/50 lg:col-span-2">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-primary" />
                {generatedDoc ? docTypeLabels[docType] : "Resultado"}
              </CardTitle>
              {generatedDoc && (
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-xs gap-1">
                    <Sparkles className="h-3 w-3 text-primary" /> Gerado por IA
                  </Badge>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={copyDoc}>
                    <Copy className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={downloadDoc}>
                    <Download className="h-3.5 w-3.5" />
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {isGenerating ? (
              <div className="flex flex-col items-center justify-center py-20 gap-4">
                <div className="relative">
                  <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center">
                    <Sparkles className="h-8 w-8 text-primary animate-pulse" />
                  </div>
                  <div className="absolute inset-0 rounded-2xl border-2 border-primary/30 animate-ping" />
                </div>
                <div className="text-center">
                  <p className="font-semibold">Gerando documentação...</p>
                  <p className="text-sm text-muted-foreground mt-1">A IA está analisando seu package</p>
                </div>
              </div>
            ) : !generatedDoc ? (
              <div className="flex flex-col items-center justify-center py-20 gap-4">
                <div className="h-16 w-16 rounded-2xl bg-muted/30 flex items-center justify-center">
                  <BookOpen className="h-8 w-8 text-muted-foreground/40" />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-muted-foreground">Nenhuma documentação gerada</p>
                  <p className="text-sm text-muted-foreground/60 mt-1">
                    Selecione um package e clique em Gerar
                  </p>
                </div>
              </div>
            ) : (
              <div className="prose prose-invert prose-sm max-w-none max-h-[600px] overflow-y-auto pr-2">
                <Streamdown>{generatedDoc}</Streamdown>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
