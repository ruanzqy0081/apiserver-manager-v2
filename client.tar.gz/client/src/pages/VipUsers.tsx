import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { Crown, Edit, RefreshCw, Shield, ShieldOff, Users } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const VIP_COLORS: Record<string, string> = {
  vip1: "text-blue-400 bg-blue-400/10 border-blue-400/20",
  vip2: "text-violet-400 bg-violet-400/10 border-violet-400/20",
  vip3: "text-amber-400 bg-amber-400/10 border-amber-400/20",
  vip4: "text-emerald-400 bg-emerald-400/10 border-emerald-400/20",
};

const VIP_LABELS: Record<string, string> = {
  vip1: "VIP 1 — 200 keys",
  vip2: "VIP 2 — 500 keys",
  vip3: "VIP 3 — 1.000 keys",
  vip4: "VIP 4 — Ilimitado",
};

export default function VipUsers() {
  const utils = trpc.useUtils();
  const { data: users, isLoading } = trpc.vipUsers.listAll.useQuery();
  const promoteMut = trpc.vipUsers.promote.useMutation({ onSuccess: () => { utils.vipUsers.listAll.invalidate(); toast.success("Usuário promovido a VIP!"); setShowPromote(null); } });
  const demoteMut = trpc.vipUsers.demote.useMutation({ onSuccess: () => { utils.vipUsers.listAll.invalidate(); toast.success("Status VIP removido!"); } });
  const updateLimitsMut = trpc.vipUsers.updateLimits.useMutation({ onSuccess: () => { utils.vipUsers.listAll.invalidate(); toast.success("Limites atualizados!"); setEditLimits(null); } });

  const [showPromote, setShowPromote] = useState<NonNullable<typeof users>[0] | null>(null);
  const [editLimits, setEditLimits] = useState<NonNullable<typeof users>[0] | null>(null);
  const [promoteForm, setPromoteForm] = useState({ vipLevel: "vip1" as "vip1" | "vip2" | "vip3" | "vip4", expiresAt: "" });
  const [limitsForm, setLimitsForm] = useState({ keyLimit: 200, dailyLimit: 1000 });

  const vipCount = users?.filter((u) => u.vip).length ?? 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Usuários VIP</h1>
          <p className="text-sm text-muted-foreground mt-1">Gerencie assinaturas e limites dos usuários</p>
        </div>
        <Badge variant="outline" className="gap-1.5 px-3 py-1.5">
          <Crown className="h-3.5 w-3.5 text-amber-400" />
          {vipCount} VIPs ativos
        </Badge>
      </div>

      {/* VIP Tiers Info */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {Object.entries(VIP_LABELS).map(([level, label]) => (
          <Card key={level} className={`border bg-card/50 ${VIP_COLORS[level].split(" ").filter(c => c.startsWith("border")).join(" ")}`}>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Crown className={`h-4 w-4 ${VIP_COLORS[level].split(" ")[0]}`} />
                <span className="text-xs font-semibold uppercase tracking-wider">{level.toUpperCase()}</span>
              </div>
              <p className="text-xs text-muted-foreground">{label}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {level === "vip4" ? "10.000 keys/dia" : "Sem limite diário"}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-border/50 bg-card/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Users className="h-4 w-4 text-primary" />
            Todos os Usuários ({users?.length ?? 0})
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-8 text-center text-muted-foreground">Carregando...</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-border/50 hover:bg-transparent">
                    <TableHead className="text-xs text-muted-foreground">Usuário</TableHead>
                    <TableHead className="text-xs text-muted-foreground">Email</TableHead>
                    <TableHead className="text-xs text-muted-foreground">Role</TableHead>
                    <TableHead className="text-xs text-muted-foreground">VIP</TableHead>
                    <TableHead className="text-xs text-muted-foreground">Limite Keys</TableHead>
                    <TableHead className="text-xs text-muted-foreground">VIP Expira</TableHead>
                    <TableHead className="text-xs text-muted-foreground w-24">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users?.map((user) => (
                    <TableRow key={user.id} className="border-border/30 hover:bg-accent/20">
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary shrink-0">
                            {user.name?.charAt(0).toUpperCase() ?? "U"}
                          </div>
                          <span className="text-sm font-medium">{user.name || "—"}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">{user.email || "—"}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={user.role === "admin" ? "text-primary border-primary/30" : "text-muted-foreground"}>
                          {user.role === "admin" ? "Admin" : "Usuário"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {user.vip ? (
                          <Badge className={`${VIP_COLORS[user.vip.vipLevel]} text-xs border`}>
                            <Crown className="h-3 w-3 mr-1" />
                            {user.vip.vipLevel.toUpperCase()}
                          </Badge>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {user.vip ? user.vip.keyLimit.toLocaleString() : "—"}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {user.vip?.expiresAt ? new Date(user.vip.expiresAt).toLocaleDateString("pt-BR") : "—"}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {user.vip ? (
                            <>
                              <Button
                                variant="ghost" size="icon" className="h-7 w-7"
                                onClick={() => { setEditLimits(user); setLimitsForm({ keyLimit: user.vip!.keyLimit, dailyLimit: user.vip!.dailyLimit }); }}
                              >
                                <Edit className="h-3.5 w-3.5" />
                              </Button>
                              <Button
                                variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive"
                                onClick={() => { if (confirm("Remover VIP deste usuário?")) demoteMut.mutate({ userId: user.id }); }}
                              >
                                <ShieldOff className="h-3.5 w-3.5" />
                              </Button>
                            </>
                          ) : (
                            <Button
                              variant="ghost" size="sm" className="h-7 text-xs gap-1 text-primary hover:text-primary"
                              onClick={() => { setShowPromote(user); setPromoteForm({ vipLevel: "vip1", expiresAt: "" }); }}
                            >
                              <Shield className="h-3.5 w-3.5" /> Promover
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Promote Dialog */}
      {showPromote && (
        <Dialog open={!!showPromote} onOpenChange={() => setShowPromote(null)}>
          <DialogContent className="sm:max-w-sm">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Crown className="h-5 w-5 text-amber-400" /> Promover a VIP
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">Promovendo: <strong className="text-foreground">{showPromote.name}</strong></p>
              <div className="space-y-1.5">
                <Label>Nível VIP</Label>
                <Select value={promoteForm.vipLevel} onValueChange={(v) => setPromoteForm({ ...promoteForm, vipLevel: v as "vip1" | "vip2" | "vip3" | "vip4" })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vip1">VIP 1 — 200 keys</SelectItem>
                    <SelectItem value="vip2">VIP 2 — 500 keys</SelectItem>
                    <SelectItem value="vip3">VIP 3 — 1.000 keys</SelectItem>
                    <SelectItem value="vip4">VIP 4 — Ilimitado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Data de expiração (opcional)</Label>
                <Input type="date" value={promoteForm.expiresAt} onChange={(e) => setPromoteForm({ ...promoteForm, expiresAt: e.target.value })} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowPromote(null)}>Cancelar</Button>
              <Button onClick={() => promoteMut.mutate({ userId: showPromote.id, ...promoteForm, expiresAt: promoteForm.expiresAt || undefined })} disabled={promoteMut.isPending} className="gap-2">
                {promoteMut.isPending ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Crown className="h-4 w-4" />}
                Promover
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Edit Limits Dialog */}
      {editLimits && (
        <Dialog open={!!editLimits} onOpenChange={() => setEditLimits(null)}>
          <DialogContent className="sm:max-w-sm">
            <DialogHeader>
              <DialogTitle>Editar Limites — {editLimits.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label>Limite de Keys</Label>
                <Input type="number" min={1} value={limitsForm.keyLimit} onChange={(e) => setLimitsForm({ ...limitsForm, keyLimit: Number(e.target.value) })} />
              </div>
              <div className="space-y-1.5">
                <Label>Limite Diário</Label>
                <Input type="number" min={1} value={limitsForm.dailyLimit} onChange={(e) => setLimitsForm({ ...limitsForm, dailyLimit: Number(e.target.value) })} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditLimits(null)}>Cancelar</Button>
              <Button onClick={() => updateLimitsMut.mutate({ userId: editLimits.id, ...limitsForm })} disabled={updateLimitsMut.isPending}>
                Salvar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
